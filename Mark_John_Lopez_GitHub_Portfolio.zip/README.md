# Mark John Lopez — Student Developer Portfolio

A responsive resume-style portfolio for Mark John Lopez, an Information Technology student at CCDI.

## Files
- `index.html` — complete responsive portfolio website.
- `README.md` — these instructions.

## Customize before publishing
1. Open `index.html` in Visual Studio Code.
2. Verify your name, school details, email address, and GitHub link.
3. The GitHub profile link is set to `https://github.com/Markyy1109`.
4. Replace the sample email `markjohnlopez@example.com` with your real contact email, or remove the email button.
5. Update project descriptions and achievements so they accurately reflect work you have completed. Entries labeled as examples are not verified achievements.
6. Add repository links, screenshots, dates, and certificates where appropriate.

## Projects featured
- Calculator
- PHP/MySQL application
- Mini game
- Personal website
- School management system
- Other applications / spreadsheet tool

## Publish using GitHub Pages
1. Sign in to GitHub and create a repository such as `markyy1109.github.io` or `my-portfolio`.
2. Upload `index.html` and `README.md` to the repository's main branch.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish the site. GitHub will display the website URL in the Pages section.

This ZIP contains website source files. It is not automatically published online.
